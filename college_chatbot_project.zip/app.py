import streamlit as st
from chatbot import load_docs, create_vector_store, get_chatbot
from dotenv import load_dotenv

load_dotenv()
st.set_page_config(page_title="College Chatbot", layout="centered")
st.title("🎓 Smart College Chatbot")

@st.cache_resource
def setup_chatbot():
    docs = load_docs("data/college_faq.pdf")
    store = create_vector_store(docs)
    return get_chatbot(store)

chatbot = setup_chatbot()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

query = st.text_input("Ask me something about the college:")
if query:
    result = chatbot({"question": query, "chat_history": st.session_state.chat_history})
    st.session_state.chat_history.append((query, result["answer"]))
    st.write("🧠 " + result["answer"])